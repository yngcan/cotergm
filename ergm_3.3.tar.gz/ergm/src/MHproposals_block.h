#ifndef MHproposals_Block_H
#define MHproposals_Block_H

#include "MHproposal.h"

void MH_blockdiag (MHproposal *MHp, Network *nwp);
void MH_blockdiagTNT (MHproposal *MHp, Network *nwp);

#endif 



