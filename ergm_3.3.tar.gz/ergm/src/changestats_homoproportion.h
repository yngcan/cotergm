#ifndef CHANGESTATS_HOMOPROPORTION
#define CHANGESTATS_HOMOPROPORTION

#include "changestat.h"

/********************  ratiostats:   H    ***********/                       
D_CHANGESTAT_FN(d_homoproportion);

#endif
