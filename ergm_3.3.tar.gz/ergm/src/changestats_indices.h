#ifndef CHANGESTATS_INDICES_H
#define CHANGESTATS_INDICES_H

#include "edgetree.h"
#include "changestat.h"

D_CHANGESTAT_FN(d_indices);

#endif
