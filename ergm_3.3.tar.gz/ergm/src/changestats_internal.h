#include "edgetree.h"
#include "changestat.h"

/********************  changestats: internal ***********/
D_CHANGESTAT_FN(d_b1degree_edgecov);
D_CHANGESTAT_FN(d_b2degree_edgecov);
D_CHANGESTAT_FN(d_b1mindegree);
D_CHANGESTAT_FN(d_b2mindegree);
D_CHANGESTAT_FN(d_b1mindegree_edgecov);
D_CHANGESTAT_FN(d_b2mindegree_edgecov);


