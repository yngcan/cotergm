#ifndef CONDDEGMPLE_H
#define CONDDEGMPLE_H

#include "wtedgetree.h"
#include "changestats.h"

/****************************************************/
/* changestat function prototypes */
/****************************************************/
D_CHANGESTAT_FN(d_conddegmple);
       
#endif
